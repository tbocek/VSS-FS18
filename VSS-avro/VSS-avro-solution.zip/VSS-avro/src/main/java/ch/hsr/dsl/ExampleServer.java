package ch.hsr.dsl;

import org.apache.avro.AvroRemoteException;
import org.apache.avro.ipc.NettyServer;
import org.apache.avro.ipc.specific.SpecificResponder;

import java.net.InetSocketAddress;

public class ExampleServer {
    public static void main(String[] args) {
        System.out.println("server starting");
        new NettyServer(new SpecificResponder(RegistrationProtocol.class, new MyService()), new InetSocketAddress(7001));
    }

    private static class MyService implements RegistrationProtocol {
        @Override
        public ReplyMessage Register(RequestMessage request) throws AvroRemoteException {
            final ReplyMessage reply;
            if(request.getPin() == 1337) {
                reply = ReplyMessage.newBuilder().setReply(
                        "SUCCESS, welcome "
                                +request.getFirstName()
                                + " "
                                + request.getLastName()
                                +" from "
                                +request.getAffiliation()).build();
            } else {
                reply = ReplyMessage.newBuilder().setReply(
                        "FAILED: wrong pin: "
                                +request.getPin()
                                +" for "
                                +request.getFirstName()
                                + " "
                                + request.getLastName()).build();
            }
            System.out.println("server replied: " + reply.getReply());
            return reply;
        }
    }
}