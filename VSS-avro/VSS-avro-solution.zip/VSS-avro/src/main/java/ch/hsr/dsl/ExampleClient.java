package ch.hsr.dsl;

import org.apache.avro.ipc.NettyTransceiver;
import org.apache.avro.ipc.specific.SpecificRequestor;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;

public class ExampleClient {
    public static void main(String[] args) throws IOException {
        NettyTransceiver client = new NettyTransceiver(new InetSocketAddress(InetAddress.getByName("localhost"),7001));
        RegistrationProtocol proxy = SpecificRequestor.getClient(RegistrationProtocol.class, client);

        RequestMessage request = RequestMessage.newBuilder()
                .setFirstName("Thomas")
                .setLastName("Bocek")
                .setAffiliation("HSR")
                .setPin(1337)
                .build();
        System.out.println("client sends: "+request.getPin());
        ReplyMessage reply = proxy.Register(request);
        System.out.println("client received: "+reply.getReply());
        client.close();
    }
}